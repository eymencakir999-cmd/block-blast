import { useState, useEffect, useCallback, useRef } from 'react';

// ========== TYPES ==========
interface Block {
  id: string;
  shape: number[][];
  color: string;
}

interface Position {
  row: number;
  col: number;
}

// ========== BLOCK SHAPES ==========
// Her blok şekli için matris tanımları
const BLOCK_SHAPES: number[][][] = [
  // Tek kare
  [[1]],
  // 2'li yatay çizgi
  [[1, 1]],
  // 2'li dikey çizgi
  [[1], [1]],
  // 3'lü yatay çizgi
  [[1, 1, 1]],
  // 3'lü dikey çizgi
  [[1], [1], [1]],
  // L şekli (normal)
  [[1, 0], [1, 0], [1, 1]],
  // L şekli (ters)
  [[0, 1], [0, 1], [1, 1]],
  // L şekli (sağa dönmüş)
  [[1, 1, 1], [1, 0, 0]],
  // L şekli (sola dönmüş)
  [[1, 1, 1], [0, 0, 1]],
  // 2x2 kare
  [[1, 1], [1, 1]],
  // T şekli
  [[1, 1, 1], [0, 1, 0]],
  // T şekli (ters)
  [[0, 1, 0], [1, 1, 1]],
  // Zigzag (S)
  [[0, 1, 1], [1, 1, 0]],
  // Zigzag (Z)
  [[1, 1, 0], [0, 1, 1]],
];

// Canlı neon renkler
const BLOCK_COLORS = [
  '#FF6B6B', // Kırmızı
  '#4ECDC4', // Turkuaz
  '#45B7D1', // Mavi
  '#96CEB4', // Yeşil
  '#FFEAA7', // Sarı
  '#DDA0DD', // Mor
  '#FF9F43', // Turuncu
  '#A29BFE', // Lavanta
  '#FD79A8', // Pemba
  '#00B894', // Zümrüt
];

const GRID_SIZE = 10;
const STORAGE_KEY = 'blockblast_highscore';

// ========== AUDIO MANAGER ==========
// Web Audio API ile ses efektleri
class AudioManager {
  private audioContext: AudioContext | null = null;

  private getContext(): AudioContext {
    if (!this.audioContext) {
      this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    return this.audioContext;
  }

  // Blok yerleştirme sesi
  playPlace() {
    try {
      const ctx = this.getContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.frequency.setValueAtTime(440, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.1);
      gain.gain.setValueAtTime(0.3, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.15);
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.15);
    } catch (e) {}
  }

  // Satır temizleme sesi
  playClear(combo: number) {
    try {
      const ctx = this.getContext();
      const baseFreq = 523 + combo * 100;
      [0, 0.08, 0.16].forEach((delay, i) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.type = 'sine';
        osc.frequency.setValueAtTime(baseFreq + i * 200, ctx.currentTime + delay);
        gain.gain.setValueAtTime(0.25, ctx.currentTime + delay);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + delay + 0.2);
        osc.start(ctx.currentTime + delay);
        osc.stop(ctx.currentTime + delay + 0.2);
      });
    } catch (e) {}
  }

  // Game over sesi
  playGameOver() {
    try {
      const ctx = this.getContext();
      [0, 0.15, 0.3].forEach((delay, i) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(400 - i * 100, ctx.currentTime + delay);
        gain.gain.setValueAtTime(0.2, ctx.currentTime + delay);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + delay + 0.3);
        osc.start(ctx.currentTime + delay);
        osc.stop(ctx.currentTime + delay + 0.3);
      });
    } catch (e) {}
  }
}

const audioManager = new AudioManager();

// ========== MAIN APP COMPONENT ==========
export default function App() {
  // ========== STATE ==========
  // Oyun grid'i - 0 boş, doluysa renk kodu
  const [grid, setGrid] = useState<string[][]>(() => 
    Array(GRID_SIZE).fill(null).map(() => Array(GRID_SIZE).fill(''))
  );
  
  // Mevcut bloklar
  const [blocks, setBlocks] = useState<Block[]>([]);
  
  // Sürüklenen blok
  const [draggingBlock, setDraggingBlock] = useState<Block | null>(null);
  
  // Sürüklenen blokun grid üzerindeki konumu
  const [dragPosition, setDragPosition] = useState<Position | null>(null);
  
  // Geçerli yerleştirme durumu
  const [isValidPlacement, setIsValidPlacement] = useState(false);
  
  // Skor
  const [score, setScore] = useState(0);
  
  // En yüksek skor
  const [highScore, setHighScore] = useState(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved ? parseInt(saved, 10) : 0;
  });
  
  // Oyun durumu
  const [gameOver, setGameOver] = useState(false);
  
  // Temizlenen satırlar animasyonu için
  const [clearingCells, setClearingCells] = useState<Set<string>>(new Set());
  
  // Skor animasyonu
  const [scorePopups, setScorePopups] = useState<{id: number, value: number, x: number, y: number}[]>([]);
  
  // Intro animasyonu
  const [showIntro, setShowIntro] = useState(true);
  
  // Ref'ler
  const gridRef = useRef<HTMLDivElement>(null);
  const popupIdRef = useRef(0);

  // ========== FONKSİYONLAR ==========
  
  // Rastgele blok oluştur (zorluk seviyesine göre)
  const generateBlock = useCallback((): Block => {
    // Zorluk arttıkça daha büyük bloklar çıkma olasılığı artar
    const difficulty = Math.min(score / 5000, 1);
    const availableShapes = BLOCK_SHAPES.filter((shape) => {
      const size = shape.flat().reduce((a, b) => a + b, 0);
      return size <= 4 + Math.floor(difficulty * 4);
    });
    
    const shape = availableShapes[Math.floor(Math.random() * availableShapes.length)];
    const color = BLOCK_COLORS[Math.floor(Math.random() * BLOCK_COLORS.length)];
    
    return {
      id: `block-${Date.now()}-${Math.random()}`,
      shape,
      color,
    };
  }, [score]);

  // 3 yeni blok oluştur
  const generateNewBlocks = useCallback(() => {
    setBlocks([generateBlock(), generateBlock(), generateBlock()]);
  }, [generateBlock]);

  // Oyunu başlat
  const startGame = useCallback(() => {
    setGrid(Array(GRID_SIZE).fill(null).map(() => Array(GRID_SIZE).fill('')));
    setScore(0);
    setGameOver(false);
    setClearingCells(new Set());
    generateNewBlocks();
    setShowIntro(false);
  }, [generateNewBlocks]);

  // İlk yükleme
  useEffect(() => {
    const timer = setTimeout(() => {
      if (showIntro) {
        startGame();
      }
    }, 2000);
    return () => clearTimeout(timer);
  }, [showIntro, startGame]);

  // En yüksek skoru kaydet
  useEffect(() => {
    if (score > highScore) {
      setHighScore(score);
      localStorage.setItem(STORAGE_KEY, score.toString());
    }
  }, [score, highScore]);

  // Bloğun geçerli konuma yerleştirilip yerleştirilemeyeceğini kontrol et
  const canPlaceBlock = useCallback((block: Block, position: Position, currentGrid: string[][]): boolean => {
    const { shape } = block;
    const { row, col } = position;
    
    for (let r = 0; r < shape.length; r++) {
      for (let c = 0; c < shape[r].length; c++) {
        if (shape[r][c] === 1) {
          const newRow = row + r;
          const newCol = col + c;
          
          // Grid sınırları kontrolü
          if (newRow < 0 || newRow >= GRID_SIZE || newCol < 0 || newCol >= GRID_SIZE) {
            return false;
          }
          
          // Çarpışma kontrolü
          if (currentGrid[newRow][newCol] !== '') {
            return false;
          }
        }
      }
    }
    return true;
  }, []);

  // Tamamlanan satırları bul ve temizle
  const clearCompleteLines = useCallback((currentGrid: string[][]): { newGrid: string[][], clearedCount: number, clearedCells: Set<string> } => {
    const newGrid = currentGrid.map(row => [...row]);
    const cellsToClear = new Set<string>();
    let clearedCount = 0;
    
    // Yatay satırları kontrol et
    for (let r = 0; r < GRID_SIZE; r++) {
      if (newGrid[r].every(cell => cell !== '')) {
        for (let c = 0; c < GRID_SIZE; c++) {
          cellsToClear.add(`${r}-${c}`);
        }
        clearedCount++;
      }
    }
    
    // Dikey satırları kontrol et
    for (let c = 0; c < GRID_SIZE; c++) {
      let isFull = true;
      for (let r = 0; r < GRID_SIZE; r++) {
        if (newGrid[r][c] === '') {
          isFull = false;
          break;
        }
      }
      if (isFull) {
        for (let r = 0; r < GRID_SIZE; r++) {
          cellsToClear.add(`${r}-${c}`);
        }
        clearedCount++;
      }
    }
    
    // Temizleme işlemini uygula
    cellsToClear.forEach(key => {
      const [r, c] = key.split('-').map(Number);
      newGrid[r][c] = '';
    });
    
    return { newGrid, clearedCount, clearedCells: cellsToClear };
  }, []);

  // Bloğu yerleştir
  const placeBlock = useCallback((block: Block, position: Position) => {
    if (!canPlaceBlock(block, position, grid)) return false;
    
    // Yeni grid oluştur
    const newGrid = grid.map(row => [...row]);
    const { shape, color } = block;
    const { row, col } = position;
    
    for (let r = 0; r < shape.length; r++) {
      for (let c = 0; c < shape[r].length; c++) {
        if (shape[r][c] === 1) {
          newGrid[row + r][col + c] = color;
        }
      }
    }
    
    // Ses çal
    audioManager.playPlace();
    
    // Satırları temizle
    const { newGrid: clearedGrid, clearedCount, clearedCells } = clearCompleteLines(newGrid);
    
    // Temizleme animasyonu
    if (clearedCount > 0) {
      setClearingCells(clearedCells);
      setTimeout(() => setClearingCells(new Set()), 400);
      
      // Combo bonus puanı
      const basePoints = clearedCount * 100;
      const comboBonus = clearedCount > 1 ? clearedCount * 50 : 0;
      const totalPoints = basePoints + comboBonus;
      
      setScore(prev => prev + totalPoints);
      
      // Skor popup
      popupIdRef.current++;
      setScorePopups(prev => [...prev, {
        id: popupIdRef.current,
        value: totalPoints,
        x: Math.random() * 60 + 20,
        y: Math.random() * 30 + 35,
      }]);
      
      setTimeout(() => {
        setScorePopups(prev => prev.slice(1));
      }, 1000);
      
      // Ses çal
      audioManager.playClear(clearedCount);
    }
    
    setGrid(clearedGrid);
    
    // Kullanılan bloğu kaldır
    setBlocks(prev => {
      const remaining = prev.filter(b => b.id !== block.id);
      
      // Tüm bloklar kullanıldıysa yeni bloklar oluştur
      if (remaining.length === 0) {
        return []; // Boş döndür, useEffect ile doldurulacak
      }
      return remaining;
    });
    
    // Yerleştirilecek blok olup olmadığını kontrol et
    setTimeout(() => {
      checkGameOver(clearedGrid);
    }, 100);
    
    return true;
  }, [grid, canPlaceBlock, clearCompleteLines]);

  // Game over kontrolü
  const checkGameOver = useCallback((currentGrid: string[][], currentBlocks?: Block[]) => {
    const blocksToCheck = currentBlocks || blocks;
    
    if (blocksToCheck.length === 0) return;
    
    const canPlaceAny = blocksToCheck.some(block => {
      for (let r = 0; r <= GRID_SIZE - block.shape.length; r++) {
        for (let c = 0; c <= GRID_SIZE - (block.shape[0]?.length || 0); c++) {
          if (canPlaceBlock(block, { row: r, col: c }, currentGrid)) {
            return true;
          }
        }
      }
      return false;
    });
    
    if (!canPlaceAny && blocksToCheck.length > 0) {
      setGameOver(true);
      audioManager.playGameOver();
    }
  }, [blocks, canPlaceBlock]);

  // Bloklar değiştiğinde ve boşsa yeni bloklar oluştur
  useEffect(() => {
    if (blocks.length === 0 && !gameOver && !showIntro) {
      const newBlocks = [generateBlock(), generateBlock(), generateBlock()];
      setBlocks(newBlocks);
      
      // Yeni bloklarla game over kontrolü
      setTimeout(() => {
        checkGameOver(grid, newBlocks);
      }, 100);
    }
  }, [blocks, gameOver, showIntro, generateBlock, grid, checkGameOver]);

  // ========== DRAG & DROP HANDLERS ==========
  
  // Sürüklemeye başla
  const handleDragStart = (block: Block) => {
    setDraggingBlock(block);
  };

  // Touch olayları için
  const handleTouchStart = (block: Block, e: React.TouchEvent) => {
    e.preventDefault();
    setDraggingBlock(block);
  };

  // Grid üzerinde fare/touch hareketi
  const handleGridMove = (e: React.MouseEvent | React.TouchEvent) => {
    if (!draggingBlock || !gridRef.current) return;
    
    const rect = gridRef.current.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
    
    const cellSize = rect.width / GRID_SIZE;
    const col = Math.floor((clientX - rect.left) / cellSize);
    const row = Math.floor((clientY - rect.top) / cellSize);
    
    // Blok merkezini hesaba kat
    const adjustedCol = Math.floor(col - (draggingBlock.shape[0]?.length || 0) / 2 + 0.5);
    const adjustedRow = Math.floor(row - draggingBlock.shape.length / 2 + 0.5);
    
    const position = { row: adjustedRow, col: adjustedCol };
    setDragPosition(position);
    setIsValidPlacement(canPlaceBlock(draggingBlock, position, grid));
  };

  // Sürüklemeyi bırak
  const handleDrop = () => {
    if (!draggingBlock || !dragPosition) {
      setDraggingBlock(null);
      setDragPosition(null);
      return;
    }
    
    if (isValidPlacement) {
      placeBlock(draggingBlock, dragPosition);
    }
    
    setDraggingBlock(null);
    setDragPosition(null);
    setIsValidPlacement(false);
  };

  // Touch bırakma
  const handleTouchEnd = (e: React.TouchEvent) => {
    // Son touch pozisyonunu al
    if (draggingBlock && gridRef.current) {
      const touch = e.changedTouches[0];
      const rect = gridRef.current.getBoundingClientRect();
      const cellSize = rect.width / GRID_SIZE;
      const col = Math.floor((touch.clientX - rect.left) / cellSize);
      const row = Math.floor((touch.clientY - rect.top) / cellSize);
      
      const adjustedCol = Math.floor(col - (draggingBlock.shape[0]?.length || 0) / 2 + 0.5);
      const adjustedRow = Math.floor(row - draggingBlock.shape.length / 2 + 0.5);
      
      const position = { row: adjustedRow, col: adjustedCol };
      
      if (canPlaceBlock(draggingBlock, position, grid)) {
        placeBlock(draggingBlock, position);
      }
    }
    
    setDraggingBlock(null);
    setDragPosition(null);
    setIsValidPlacement(false);
  };

  // ========== RENDER ==========
  
  // Intro ekranı
  if (showIntro) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 flex items-center justify-center">
        <div className="text-center animate-pulse">
          <h1 className="text-5xl md:text-7xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 mb-4">
            BLOCK BLAST
          </h1>
          <p className="text-gray-400 text-lg">Yükleniyor...</p>
        </div>
      </div>
    );
  }

  return (
    <div 
      className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 flex flex-col items-center justify-center p-2 md:p-4 select-none"
      onMouseMove={handleGridMove}
      onMouseUp={handleDrop}
      onMouseLeave={handleDrop}
      onTouchMove={handleGridMove}
      onTouchEnd={handleTouchEnd}
    >
      {/* Skor Popup'ları */}
      {scorePopups.map(popup => (
        <div
          key={popup.id}
          className="fixed text-2xl md:text-4xl font-bold text-yellow-400 animate-bounce pointer-events-none z-50"
          style={{ left: `${popup.x}%`, top: `${popup.y}%` }}
        >
          +{popup.value}
        </div>
      ))}
      
      {/* Header */}
      <div className="w-full max-w-md mb-2 md:mb-4">
        <div className="flex justify-between items-center px-2">
          <div className="text-left">
            <div className="text-gray-400 text-xs md:text-sm">SKOR</div>
            <div className="text-2xl md:text-3xl font-bold text-white">{score.toLocaleString()}</div>
          </div>
          <div className="text-right">
            <div className="text-gray-400 text-xs md:text-sm">EN YÜKSEK</div>
            <div className="text-2xl md:text-3xl font-bold text-yellow-400">{highScore.toLocaleString()}</div>
          </div>
        </div>
      </div>
      
      {/* Oyun Grid'i */}
      <div 
        ref={gridRef}
        className="relative w-[95vw] max-w-[400px] aspect-square bg-gray-800/50 rounded-xl p-1 md:p-2 backdrop-blur-sm border border-gray-700/50 shadow-2xl"
        style={{
          boxShadow: '0 0 40px rgba(139, 92, 246, 0.3), inset 0 0 20px rgba(0, 0, 0, 0.5)',
        }}
      >
        {/* Grid çizgileri */}
        <div 
          className="grid w-full h-full gap-[2px]"
          style={{
            gridTemplateColumns: `repeat(${GRID_SIZE}, 1fr)`,
          }}
        >
          {grid.map((row, rowIndex) =>
            row.map((cell, colIndex) => {
              const cellKey = `${rowIndex}-${colIndex}`;
              const isClearing = clearingCells.has(cellKey);
              
              // Sürüklenen blokun bu hücreye düşüp düşmediğini kontrol et
              let isHighlight = false;
              let highlightColor = '';
              
              if (draggingBlock && dragPosition) {
                const { shape } = draggingBlock;
                for (let r = 0; r < shape.length; r++) {
                  for (let c = 0; c < shape[r].length; c++) {
                    if (shape[r][c] === 1 && 
                        dragPosition.row + r === rowIndex && 
                        dragPosition.col + c === colIndex) {
                      isHighlight = true;
                      highlightColor = isValidPlacement ? '#22c55e' : '#ef4444';
                    }
                  }
                }
              }
              
              return (
                <div
                  key={cellKey}
                  className={`
                    rounded-sm transition-all duration-150
                    ${cell ? 'scale-100' : 'bg-gray-700/30'}
                    ${isClearing ? 'animate-ping' : ''}
                  `}
                  style={{
                    backgroundColor: cell || (isHighlight ? highlightColor : undefined),
                    boxShadow: cell 
                      ? `0 0 8px ${cell}, inset 0 0 4px rgba(255,255,255,0.3)` 
                      : isHighlight 
                        ? `0 0 10px ${highlightColor}` 
                        : 'none',
                    opacity: isClearing ? 0 : 1,
                  }}
                />
              );
            })
          )}
        </div>
      </div>
      
      {/* Bloklar */}
      <div className="w-full max-w-md mt-4 md:mt-6">
        <div className="flex justify-center items-center gap-3 md:gap-6 px-2">
          {blocks.map((block) => (
            <div
              key={block.id}
              className={`
                cursor-grab active:cursor-grabbing transition-transform duration-200
                ${draggingBlock?.id === block.id ? 'opacity-50 scale-110' : 'hover:scale-105'}
              `}
              onMouseDown={() => handleDragStart(block)}
              onTouchStart={(e) => handleTouchStart(block, e)}
            >
              <div 
                className="flex flex-col items-center p-2 md:p-3 bg-gray-800/70 rounded-lg border border-gray-600/50"
                style={{
                  boxShadow: `0 0 15px ${block.color}40`,
                }}
              >
                {block.shape.map((row, rowIndex) => (
                  <div key={rowIndex} className="flex">
                    {row.map((cell, colIndex) => (
                      <div
                        key={colIndex}
                        className="w-5 h-5 md:w-7 md:h-7 m-[1px] rounded-sm"
                        style={{
                          backgroundColor: cell ? block.color : 'transparent',
                          boxShadow: cell 
                            ? `0 0 6px ${block.color}, inset 0 0 3px rgba(255,255,255,0.3)` 
                            : 'none',
                        }}
                      />
                    ))}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
      
      {/* Game Over Ekranı */}
      {gameOver && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 animate-fade-in">
          <div className="bg-gradient-to-br from-gray-800 to-gray-900 p-6 md:p-8 rounded-2xl text-center border border-gray-600 shadow-2xl mx-4"
               style={{ boxShadow: '0 0 40px rgba(239, 68, 68, 0.3)' }}>
            <h2 className="text-3xl md:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-orange-500 mb-4">
              GAME OVER
            </h2>
            <div className="mb-6">
              <p className="text-gray-400 mb-2">Skorun</p>
              <p className="text-4xl md:text-6xl font-bold text-white">{score.toLocaleString()}</p>
            </div>
            {score >= highScore && score > 0 && (
              <p className="text-yellow-400 text-lg mb-4 animate-pulse">🎉 Yeni Rekor! 🎉</p>
            )}
            <button
              onClick={startGame}
              className="px-8 py-3 bg-gradient-to-r from-cyan-500 to-purple-600 text-white font-bold rounded-full 
                         hover:from-cyan-400 hover:to-purple-500 transition-all duration-300 transform hover:scale-105
                         shadow-lg hover:shadow-cyan-500/50"
            >
              Yeniden Oyna
            </button>
          </div>
        </div>
      )}
      
      {/* Alt bilgi */}
      <div className="mt-4 text-gray-500 text-xs md:text-sm text-center">
        Blokları sürükleyerek grid'e yerleştirin
      </div>
      
      {/* Animasyon CSS */}
      <style>{`
        @keyframes fade-in {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        .animate-fade-in {
          animation: fade-in 0.3s ease-out;
        }
      `}</style>
    </div>
  );
}
