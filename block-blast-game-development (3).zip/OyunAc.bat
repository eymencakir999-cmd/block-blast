@echo off
chcp 65001 >nul
title Block Blast Oyunu
echo.
echo  ╔════════════════════════════════════╗
echo  ║      BLOCK BLAST YUKLENIYOR...     ║
echo  ╚════════════════════════════════════╝
echo.
timeout /t 1 /nobreak >nul
start "" "%~dp0BlockBlast.html"
exit
